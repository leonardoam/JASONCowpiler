/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tadsemantico;

/**
 *
 * @author emanuel
 */
interface Type {
    
    public boolean set(String field, Object value);
    public Object get(String field);
    
}
